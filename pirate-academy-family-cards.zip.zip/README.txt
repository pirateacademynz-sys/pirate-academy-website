My 7-Day Family Cards — Pirate Academy
Powered by Faith · Made for Families · Inspired by the Quran

HOW TO USE
1. Open "family-cards.html" in any web browser (double-click it).
2. Read one card each day with your family:
   - the ayah, the daily affirmation, the 3 actions and the dua.
3. To keep or print a copy: click "Print / Save as PDF" (or your browser's Print).

This resource is free to use and share for families and classrooms.
© Pirate Academy — pirateacademy.co.nz — hello@pirateacademy.co.nz
